package DetectorTest;
//import org.apache.tika.exception.TikaException;
//import org.xml.sax.SAXException;
//
//import java.io.IOException;
//
//public class Main {
//    public static void main(String[] args) throws IOException, SAXException, TikaException {
//        String fileUrl = "/Users/KYUMIN/pjt/test3.hwp";
//        String parseString = new Extractor().extract(fileUrl);
//
//        new Validation().validate(parseString, "UTF-8");
//    }
//}


///////////////////////
// Validation 아래 main으로 일단 실행
// Tika는 전체적인 실행된 이후에 생각
///////////////////////